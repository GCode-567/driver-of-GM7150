#ifndef GM7150_H
#define GM7150_H

#include "stm32f1xx_hal.h"

#ifdef __cplusplus
extern "C" {
#endif

/* HAL expects the 7-bit I2C address shifted left by one bit. */
#define GM7150_I2C_ADDR_I2CSEL_LOW   0xB8U
#define GM7150_I2C_ADDR_I2CSEL_HIGH  0xBAU

typedef struct
{
  I2C_HandleTypeDef *hi2c;
  uint16_t i2c_address;
  GPIO_TypeDef *reset_port;
  uint16_t reset_pin;
} GM7150_Device;

typedef enum
{
  GM7150_INPUT_CVBS_A = 0x00U,
  GM7150_INPUT_SVIDEO = 0x01U,
  GM7150_INPUT_CVBS_B = 0x02U
} GM7150_Input;

typedef struct
{
  uint8_t raw;
  uint8_t standard_50hz;
  uint8_t interlaced;
  uint8_t unlocked;
  uint8_t color_carrier_locked;
  uint8_t field_sync_locked;
  uint8_t line_locked;
  uint8_t vcr_mode;
} GM7150_Status;

HAL_StatusTypeDef GM7150_Init(GM7150_Device *device);
HAL_StatusTypeDef GM7150_HardwareReset(GM7150_Device *device);
HAL_StatusTypeDef GM7150_ReadRegister(GM7150_Device *device,
                                      uint8_t reg,
                                      uint8_t *value);
HAL_StatusTypeDef GM7150_WriteRegister(GM7150_Device *device,
                                       uint8_t reg,
                                       uint8_t value);
HAL_StatusTypeDef GM7150_SelectInput(GM7150_Device *device,
                                     GM7150_Input input);
HAL_StatusTypeDef GM7150_ConfigureBT656(GM7150_Device *device);
HAL_StatusTypeDef GM7150_ReadStatus(GM7150_Device *device,
                                    GM7150_Status *status);
HAL_StatusTypeDef GM7150_IsVideoLocked(GM7150_Device *device,
                                       uint8_t *locked);

#ifdef __cplusplus
}
#endif

#endif /* GM7150_H */

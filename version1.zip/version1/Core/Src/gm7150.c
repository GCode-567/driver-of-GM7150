#include "gm7150.h"

/* GM7150 使用到的寄存器子地址，均为 8 位地址。 */
/* 00h：视频输入选择寄存器，MODE[1:0] 用于选择模拟输入接口。 */
#define GM7150_REG_INPUT_SELECT       0x00U
/* 03h：端口信号输出控制寄存器，控制数据、同步及时钟等输出。 */
#define GM7150_REG_PORT_CONTROL       0x03U
/* 0Dh：视频输出格式寄存器，用于选择 BT.601/BT.656 等数据格式。 */
#define GM7150_REG_VIDEO_OUTPUT       0x0DU
/* 0Fh：端口输出选择寄存器，用于选择 PCLK/SCLK 等复用功能。 */
#define GM7150_REG_PORT_SELECT        0x0FU
/* 88h：状态寄存器 1，包含制式、隔行及行/场锁定状态。 */
#define GM7150_REG_STATUS_1           0x88U

/* 00h bit[1:0]：输入源选择位掩码，修改时保留该寄存器其他位。 */
#define GM7150_INPUT_SELECT_MASK      0x03U

/* 03h bit3：置 1 后使能 YOUT[7:0] 输出 YCbCr 数据。 */
#define GM7150_PORT_YCBCR_ENABLE      0x08U
/* 03h bit0：置 1 后使能时钟输出；与 bit3 同置位对应手册推荐值 09h。 */
#define GM7150_PORT_CLOCK_ENABLE      0x01U

/* 0Dh bit[2:0]：视频输出格式字段的位掩码。 */
#define GM7150_VIDEO_FORMAT_MASK      0x07U
/* 0Dh bit[2:0]=111：选择 8 位 ITU-R BT.656 YCbCr 输出。 */
#define GM7150_VIDEO_FORMAT_BT656     0x07U

/* 0Fh bit0：PCLK/SCLK 引脚时钟源选择位的掩码。 */
#define GM7150_PORT_PIXEL_CLOCK       0x01U

/* 88h bit5：场频状态，1 表示 50 Hz，0 表示 60 Hz。 */
#define GM7150_STATUS_50HZ            0x20U
/* 88h bit6：隔行状态，1 表示隔行。 */
#define GM7150_STATUS_INTERLACED      0x40U
/* 88h bit4：失锁标志，1 表示失锁。 */
#define GM7150_STATUS_UNLOCKED        0x10U
/* 88h bit3：色彩载波锁定状态，1 表示已锁定。 */
#define GM7150_STATUS_COLOR_LOCK      0x08U
/* 88h bit2：场同步锁定状态，1 表示已锁定。 */
#define GM7150_STATUS_FIELD_LOCK      0x04U
/* 88h bit1：行同步锁定状态，1 表示已锁定。 */
#define GM7150_STATUS_LINE_LOCK       0x02U
/* 88h bit0：TV/VCR 状态，1 表示 VCR 模式，0 表示 TV 模式。 */
#define GM7150_STATUS_VCR             0x01U

/* HAL 阻塞式 I2C 操作的等待超时时间，单位为毫秒。 */
#define GM7150_I2C_TIMEOUT_MS         100U

/**
 * @brief 检查设备结构体和板级参数是否有效。
 * @param device 包含 I2C 句柄、设备地址和可选复位 GPIO 的设备配置。
 * @retval 1 参数有效；0 参数无效。
 */
static uint8_t device_is_valid(const GM7150_Device *device)
{
  if ((device == NULL) || (device->hi2c == NULL))
  {
    return 0U;
  }

  if ((device->i2c_address != GM7150_I2C_ADDR_I2CSEL_LOW) &&
      (device->i2c_address != GM7150_I2C_ADDR_I2CSEL_HIGH))
  {
    return 0U;
  }

  if ((device->reset_port == NULL) && (device->reset_pin != 0U))
  {
    return 0U;
  }

  if ((device->reset_port != NULL) &&
      ((device->reset_pin == 0U) ||
       ((device->reset_pin & (uint16_t)(device->reset_pin - 1U)) != 0U)))
  {
    return 0U;
  }

  return 1U;
}

/**
 * @brief 采用读-改-写方式更新寄存器中的指定字段。
 * @param device GM7150 设备配置。
 * @param reg 目标寄存器子地址。
 * @param mask 需要更新的位掩码，掩码中为 1 的位会被修改。
 * @param value 新字段值；掩码之外的位保持不变。
 * @retval HAL 状态码；寄存器读取或写入失败时返回对应错误。
 */
static HAL_StatusTypeDef update_register(GM7150_Device *device,
                                         uint8_t reg,
                                         uint8_t mask,
                                         uint8_t value)
{
  uint8_t current;
  HAL_StatusTypeDef result;

  result = GM7150_ReadRegister(device, reg, &current);
  if (result != HAL_OK)
  {
    return result;
  }

  /* 只替换 mask 指定的位，保留寄存器中其他位的原有配置。 */
  current = (uint8_t)((current & (uint8_t)~mask) | (value & mask));
  return GM7150_WriteRegister(device, reg, current);
}

/**
 * @brief 读取 GM7150 的一个 8 位寄存器。
 * @param device GM7150 设备配置。
 * @param reg 要读取的寄存器子地址。
 * @param value 接收读出数据的变量指针。
 * @retval HAL 状态码；参数无效时返回 HAL_ERROR。
 */
HAL_StatusTypeDef GM7150_ReadRegister(GM7150_Device *device,
                                      uint8_t reg,
                                      uint8_t *value)
{
  if ((device_is_valid(device) == 0U) || (value == NULL))
  {
    return HAL_ERROR;
  }

  /* HAL 使用已左移一位的设备地址：I2CSEL 低为 0xB8，高为 0xBA。 */
  return HAL_I2C_Mem_Read(device->hi2c,
                          device->i2c_address,
                          reg,
                          I2C_MEMADD_SIZE_8BIT,
                          value,
                          1U,
                          GM7150_I2C_TIMEOUT_MS);
}

/**
 * @brief 向 GM7150 的一个 8 位寄存器写入数据。
 * @param device GM7150 设备配置。
 * @param reg 要写入的寄存器子地址。
 * @param value 要写入的 8 位数据。
 * @retval HAL 状态码；参数无效时返回 HAL_ERROR。
 */
HAL_StatusTypeDef GM7150_WriteRegister(GM7150_Device *device,
                                       uint8_t reg,
                                       uint8_t value)
{
  if (device_is_valid(device) == 0U)
  {
    return HAL_ERROR;
  }

  /* 向指定寄存器子地址写入一个字节。 */
  return HAL_I2C_Mem_Write(device->hi2c,
                           device->i2c_address,
                           reg,
                           I2C_MEMADD_SIZE_8BIT,
                           &value,
                           1U,
                           GM7150_I2C_TIMEOUT_MS);
}

/**
 * @brief 使用 MCU GPIO 对 GM7150 执行硬件复位。
 * @param device GM7150 设备配置，必须提供有效的 reset_port 和 reset_pin。
 * @retval HAL_OK 复位时序已执行；配置无效或未配置复位引脚时返回 HAL_ERROR。
 * @note RESETB 为低有效；复位时板级 PDN 必须为高，且电源须已稳定。
 */
HAL_StatusTypeDef GM7150_HardwareReset(GM7150_Device *device)
{
  if ((device_is_valid(device) == 0U) || (device->reset_port == NULL))
  {
    return HAL_ERROR;
  }

  /* RESETB 为低有效，手册要求 PDN=高时复位才有效。
   * 电源应先稳定至少 20 ms，再拉低 RESETB 并释放。
   */
  HAL_GPIO_WritePin(device->reset_port, device->reset_pin, GPIO_PIN_RESET);
  HAL_Delay(20U);
  HAL_GPIO_WritePin(device->reset_port, device->reset_pin, GPIO_PIN_SET);
  HAL_Delay(10U);

  return HAL_OK;
}

/**
 * @brief 选择 GM7150 的模拟视频输入通道。
 * @param device GM7150 设备配置。
 * @param input 输入类型：CVBS A、CVBS B 或 S-Video。
 * @retval HAL 状态码；输入类型无效或 I2C 操作失败时返回错误。
 * @note CVBS A 对应 AIP1A，CVBS B 对应 AIP1B，S-Video 使用 AIP1A/AIP1B。
 */
HAL_StatusTypeDef GM7150_SelectInput(GM7150_Device *device,
                                     GM7150_Input input)
{
  if ((input != GM7150_INPUT_CVBS_A) &&
      (input != GM7150_INPUT_CVBS_B) &&
      (input != GM7150_INPUT_SVIDEO))
  {
    return HAL_ERROR;
  }

  /* 只更新 00h 的 MODE[1:0]，保留输入选择寄存器中的其他配置位。 */
  return update_register(device,
                         GM7150_REG_INPUT_SELECT,
                         GM7150_INPUT_SELECT_MASK,
                         (uint8_t)input);
}

/**
 * @brief 配置 GM7150 输出 8 位 BT.656 YCbCr 数据和像素时钟。
 * @param device GM7150 设备配置。
 * @retval HAL 状态码；任一寄存器读写失败时返回对应错误。
 * @note 设置 03h 数据/时钟输出、0Dh BT.656 格式及 0Fh PCLK 时钟源。
 */
HAL_StatusTypeDef GM7150_ConfigureBT656(GM7150_Device *device)
{
  HAL_StatusTypeDef result;

  /* 03h：使能 YOUT[7:0] 的 YCbCr 数据输出和时钟输出，对应手册推荐值 09h。
   * 使用掩码更新，保留端口控制寄存器中的其他配置位。
   */
  result = update_register(device,
                           GM7150_REG_PORT_CONTROL,
                           GM7150_PORT_YCBCR_ENABLE |
                           GM7150_PORT_CLOCK_ENABLE,
                           GM7150_PORT_YCBCR_ENABLE |
                           GM7150_PORT_CLOCK_ENABLE);
  if (result != HAL_OK)
  {
    return result;
  }

  /* 0Dh[2:0]=111 选择 8 位 BT.656，保留码值范围和色度编码等其他设置。 */
  result = update_register(device,
                           GM7150_REG_VIDEO_OUTPUT,
                           GM7150_VIDEO_FORMAT_MASK,
                           GM7150_VIDEO_FORMAT_BT656);
  if (result != HAL_OK)
  {
    return result;
  }

  /* 0Fh bit0=1：令 PCLK/SCLK 引脚输出像素时钟 PCLK，而不是系统时钟 SCLK。 */
  return update_register(device,
                         GM7150_REG_PORT_SELECT,
                         GM7150_PORT_PIXEL_CLOCK,
                         GM7150_PORT_PIXEL_CLOCK);
}

/**
 * @brief 检查设备并完成 GM7150 的基础初始化。
 * @param device GM7150 设备配置。
 * @retval HAL 状态码；设备探测或 BT.656 寄存器配置失败时返回对应错误。
 * @note 若配置了复位引脚，先执行硬件复位；随后探测 I2C 地址并设置 BT.656。
 *       此函数不选择输入源，输入通道需按实际接线另行调用 GM7150_SelectInput。
 */
HAL_StatusTypeDef GM7150_Init(GM7150_Device *device)
{
  HAL_StatusTypeDef result;

  if (device_is_valid(device) == 0U)
  {
    return HAL_ERROR;
  }

  /* 硬件复位为可选项：reset_port 为 NULL 时跳过 GPIO 复位。
   * 此时板级电路必须已通过 RESETB/PDN 提供有效的上电复位时序。
   */
  if (device->reset_port != NULL)
  {
    result = GM7150_HardwareReset(device);
    if (result != HAL_OK)
    {
      return result;
    }
  }

  /* 修改寄存器前先探测设备地址，通信失败时立即返回错误。 */
  result = HAL_I2C_IsDeviceReady(device->hi2c,
                                 device->i2c_address,
                                 3U,
                                 GM7150_I2C_TIMEOUT_MS);
  if (result != HAL_OK)
  {
    return result;
  }

  return GM7150_ConfigureBT656(device);
}

/**
 * @brief 读取并解析 GM7150 状态寄存器 88h。
 * @param device GM7150 设备配置。
 * @param status 接收原始状态字节及解析结果的结构体指针。
 * @retval HAL 状态码；参数无效或状态寄存器读取失败时返回错误。
 */
HAL_StatusTypeDef GM7150_ReadStatus(GM7150_Device *device,
                                    GM7150_Status *status)
{
  uint8_t value;
  HAL_StatusTypeDef result;

  if (status == NULL)
  {
    return HAL_ERROR;
  }

  result = GM7150_ReadRegister(device, GM7150_REG_STATUS_1, &value);
  if (result != HAL_OK)
  {
    return result;
  }

  /* 将 88h 的状态位分别解析到结构体；相应状态成立时字段值为 1。 */
  status->raw = value;
  status->standard_50hz = (uint8_t)((value & GM7150_STATUS_50HZ) != 0U);
  status->interlaced = (uint8_t)((value & GM7150_STATUS_INTERLACED) != 0U);
  status->unlocked = (uint8_t)((value & GM7150_STATUS_UNLOCKED) != 0U);
  status->color_carrier_locked = (uint8_t)((value & GM7150_STATUS_COLOR_LOCK) != 0U);
  status->field_sync_locked = (uint8_t)((value & GM7150_STATUS_FIELD_LOCK) != 0U);
  status->line_locked = (uint8_t)((value & GM7150_STATUS_LINE_LOCK) != 0U);
  status->vcr_mode = (uint8_t)((value & GM7150_STATUS_VCR) != 0U);

  return HAL_OK;
}

/**
 * @brief 判断 GM7150 当前是否已获得行、场同步锁定。
 * @param device GM7150 设备配置。
 * @param locked 输出结果指针，1 表示已锁定，0 表示未锁定。
 * @retval HAL 状态码；状态读取失败或输出指针无效时返回错误。
 * @note 判定条件为未失锁，且行同步和场同步状态均已锁定。
 */
HAL_StatusTypeDef GM7150_IsVideoLocked(GM7150_Device *device,
                                       uint8_t *locked)
{
  GM7150_Status status;
  HAL_StatusTypeDef result;

  if (locked == NULL)
  {
    return HAL_ERROR;
  }

  result = GM7150_ReadStatus(device, &status);
  if (result != HAL_OK)
  {
    return result;
  }

  /* 同时满足未失锁、行同步锁定和场同步锁定，才报告视频已锁定。 */
  *locked = (uint8_t)((status.unlocked == 0U) &&
                      (status.field_sync_locked != 0U) &&
                      (status.line_locked != 0U));
  return HAL_OK;
}

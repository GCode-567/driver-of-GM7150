/**
 * capture.c —— BT.656 接收核心
 *
 * 协议：ITU-R BT.656 嵌入式同步（8bit 并行，YUV422 交错）
 * 数据线：PB8(D0)..PB15(D7)   读法：(GPIOB->IDR >> 8) & 0xFF
 * PCLK ：PA0  上升沿 → EXTI0 中断，每拍一个字节
 * VSYNC：PA1  下降沿 → EXTI1 中断，标记一场结束（保险/奇偶场复位）
 * FID  ：（可选 PA2）用于区分奇偶场
 *
 * 设计铁律：中断里只做“喂字节 + 状态机 + 写行缓冲”，
 *          绝不 I²C、不 printf、不 DMA、不等待。
 */

#include "capture.h"
#include "frame.h"

/* ------------------- 行缓冲（唯一的大块内存） ------------------- */
/* BT.656 一行最多 1440 字节（720 像素 × YUV422），留点余量 */
#define LINE_BYTES_MAX  1536
static uint8_t line_buf[LINE_BYTES_MAX];
static uint16_t line_wptr;

/* ------------------- SAV/EAV 同步状态机 ------------------- */
typedef enum {
    SYNC_IDLE = 0,
    SYNC_GOT_FF,
    SYNC_GOT_00_1,
    SYNC_GOT_00_2,
    SYNC_GOT_XY
} sync_state_t;

static sync_state_t sync = SYNC_IDLE;
static uint8_t  trs_xy;          /* 刚收到的 XY 字节 */
static uint8_t  in_payload;      /* 1=正在有效视频区 */

/* ------------------- 场/行统计（调试用） ------------------- */
volatile uint32_t cap_sync_lost;
volatile uint32_t cap_line_short;
volatile uint32_t cap_lines_ok;
volatile uint8_t  cap_field_done;

static uint16_t cur_row;  /* 当前物理行计数（本场内） */
static uint8_t  field;    /* 由 BT.656 XY 的 F 位给出：0=第一场，1=第二场 */
static uint8_t  field_valid;

/* XY 字节定义（BT.656）: b7=1, b6=F(场,0=第一场1=第二场), b5=V, b4=H
   b3~b0 为按 F/V/H 生成的保护位。 */
#define TRS_FIRST_BYTE  0xFF

static inline int xy_is_valid(uint8_t xy)
{
    uint8_t f = (xy >> 6) & 1u;
    uint8_t v = (xy >> 5) & 1u;
    uint8_t h = (xy >> 4) & 1u;
    uint8_t protection = (uint8_t)(((v ^ h) << 3)
                                 | ((f ^ h) << 2)
                                 | ((f ^ v) << 1)
                                 | (f ^ v ^ h));
    return (xy & 0x80u) != 0u && (xy & 0x0Fu) == protection;
}

static inline int xy_is_sav(uint8_t xy)
{
    return xy_is_valid(xy) && !(xy & 0x10);     /* V=0 且 H=0 → 有效视频开始 */
}

static inline int xy_is_eav(uint8_t xy)
{
    return xy_is_valid(xy) && (xy & 0x10);      /* V=0 且 H=1 → 有效视频结束 */
}

/* 取一个字节：D0..D7 = PB8..PB15 */
static inline uint8_t read_pixel_byte(void)
{
    return (uint8_t)((GPIOB->IDR >> 8) & 0xFF);
}

/* ------------------- 公共 API ------------------- */

void CAP_Init(void)
{
    sync = SYNC_IDLE;
    line_wptr = 0;
    in_payload = 0;
    cur_row = 0;
    field_valid = 0;
    cap_sync_lost = cap_line_short = cap_lines_ok = 0;
    cap_field_done = 0;
    /* 缓冲留在 .bss，不清也行；若担心残留可 memset(line_buf,0,sizeof line_buf) */
}

/* 场结束：由 VSYNC 中断或状态机 EAV 跨场时调用 */
static void field_end(void)
{
    if (field_valid && field == CAP_SELECTED_F && !cap_field_done) {
        cap_field_done = 1;      /* 主循环看到后收尾/分包 */
    }
    cur_row = 0;
}

/* ------------------- 字节喂入（PCLK 中断里调用） ------------------- */
void CAP_FeedByte(uint8_t d)
{
    switch (sync) {

    case SYNC_IDLE:
        if (d == TRS_FIRST_BYTE) sync = SYNC_GOT_FF;
        break;

    case SYNC_GOT_FF:
        if (d == 0x00) sync = SYNC_GOT_00_1;
        else           sync = (d == 0xFF) ? SYNC_GOT_FF : SYNC_IDLE;
        break;

    case SYNC_GOT_00_1:
        if (d == 0x00) sync = SYNC_GOT_00_2;
        else           { sync = SYNC_IDLE; cap_sync_lost++; }
        break;

    case SYNC_GOT_00_2:                /* d 就是 XY */
        trs_xy = d;
        if (xy_is_valid(trs_xy)) {
            field = (trs_xy >> 6) & 1u;
            field_valid = 1;
            if (xy_is_sav(trs_xy)) {          /* 有效区开始 */
                in_payload = 1;
                line_wptr  = 0;
            } else if (xy_is_eav(trs_xy)) {   /* 有效区结束 */
                in_payload = 0;
                /* 一行收齐 → 交给 frame 层 */
                if (line_wptr >= CAP_MIN_LINE_BYTES)
                    FRM_FeedLine(line_buf, line_wptr, field, cur_row);
                else
                    cap_line_short++;

                cur_row++;
                /* 一场的有效行收完（PAL 每场约 288 行） */
                if (cur_row >= CAP_LINES_PER_FIELD)
                    field_end();
            }
            sync = SYNC_IDLE;
        } else {
            sync = (d == 0xFF) ? SYNC_GOT_FF : SYNC_IDLE;
            cap_sync_lost++;
        }
        break;

    default:
        sync = SYNC_IDLE;
        break;
    }

    /* 在有效区内：先存原始 YUV422 字节，抽 Y 交给 frame 层做 */
    if (in_payload) {
        if (line_wptr < LINE_BYTES_MAX) {
            line_buf[line_wptr++] = d;
        }
    }
}

/* ------------------- 中断挂钩（stm32f1xx_it.c 里调用） ------------------- */

void CAP_PCLK_IRQ(void)     /* 绑到 EXTI0 —— PCLK 上升沿 */
{
    /* 防重入：若用了双边沿或噪声，可判 PA0 电平；这里假定仅上升沿触发 */
    CAP_FeedByte(read_pixel_byte());
}

void CAP_VSYNC_IRQ(void)    /* 绑到 EXTI1 —— VSYNC 下降沿（保险） */
{
    /* 只在“长时间没看到 EAV 跨场”时兜底，避免双触发 */
    static uint16_t last_row_at_vs;
    if ((cur_row - last_row_at_vs) > (CAP_LINES_PER_FIELD / 2)) {
        field_end();
    }
    last_row_at_vs = cur_row;
}

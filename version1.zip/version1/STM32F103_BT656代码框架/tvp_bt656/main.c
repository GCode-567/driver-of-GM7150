/**
 * main.c —— 只做初始化 + 标志驱动的主循环
 *
 * 依赖：CubeMX 已生成
 *   SystemClock_Config() : HSE 8M -> PLLx9 = 72M, APB1/2, SWD 保留
 *   MX_GPIO_Init()        : PB8..15=输入; PA0=EXTI0上升沿; PA1=EXTI1下降沿;
 *                           PB5=RST(PP,初始HIGH); PB6/PB7=I2C1; PA9/PA10=USART1
 *   MX_I2C1_Init()        : 100kHz, 7bit, NoStretch
 *   MX_USART1_Init()      : 500000 / 8N1
 *   并在 MX_GPIO_Init() 末尾加：
 *     __HAL_RCC_AFIO_CLK_ENABLE();
 *     __HAL_AFIO_REMAP_SWJ_JTAG_DISABLE();   // 只关 JTAG，留 SWD
 */

#include "stm32f1xx_hal.h"
#include "capture.h"
#include "frame.h"
#include "uart_tx.h"
#include <stdio.h>

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_USART1_Init();

    UTX_Init();

    /* GM7150 初始化与锁定检测需依据对应模块的寄存器资料补充。 */

    /* 目标 320x240：纵向 288->240 约每 1.2 行取 1；横向在 frame 里按 Y 数自适应 */
    CAP_Init();
    FRM_Init(/*h_decim*/ 2);

    while (1) {

        /* 一场采完：收尾 + 发包 + 复位采集 */
        if (cap_field_done) {
            cap_field_done = 0;
            FRM_Finalize();        /* 发尾巴块 + EOF */
            CAP_Init();       /* 下一场重新同步 */
        }

        /* 调试口：慢速打印错误计数，确认“有没有在跑”
        static uint32_t t;
        if (HAL_GetTick() - t > 1000) { t = HAL_GetTick();
            printf("lost=%lu short=%lu\r\n", cap_sync_lost, cap_line_short); }
        */
    }
}

/* ---------- printf 重定向（半主机/Retarget 任选其一） ---------- */
int _write(int fd, char *ptr, int len)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)ptr, len, HAL_MAX_DELAY);
    return len;
}

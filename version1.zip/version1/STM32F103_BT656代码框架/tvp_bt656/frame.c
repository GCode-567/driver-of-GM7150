/**
 * frame.c —— 流式降采样：原始 BT.656 行 → 灰度小图
 *
 * 原则：不存整帧。一行一行喂进来，横向抽 Y、纵向按步长抽行，
 *       凑够一个“块”就交给 uart_tx 发包，SRAM 占用恒定。
 *
 * BT.656 有效区是 YUV422：Cb Y Cr Y ...（每个像素 2 字节，Y 在奇数位置）
 * 这里采用“每 2 字节取第 2 个 = Y”的最简取法，h_step 再在此基础上稀疏。
 */

#include "frame.h"
#include "capture.h"
#include "uart_tx.h"
#include <string.h>

/* ---- 目标尺寸（这里定 320×240；想更快改成 160×120） ---- */
#define OUT_W  320u
#define OUT_H  240u
#define BLOCK_ROWS  16u                 /* 每 16 行打一个包，防 SRAM 爆 */
#define PAYLOAD_MAX  (OUT_W * BLOCK_ROWS)

static uint8_t  block[PAYLOAD_MAX];
static uint16_t block_rows;             /* 本块已攒的行数 */
static uint16_t out_row;                /* 全局已输出的行数（0..OUT_H-1） */

static uint16_t h_step = 2;             /* 默认：每 2 个 YUV 字节抽 1 个 Y，再按需求稀化 */

void FRM_Init(uint16_t h_decim)
{
    h_step     = h_decim ? h_decim : 2;
    block_rows = 0;
    out_row    = 0;
    memset(block, 0, sizeof block);
}

/**
 * 喂入一行“原始 BT.656 有效区”字节（含 YUV422）。
 * field / row_in_field 暂只用于以后做奇偶场对齐，这里先忽略。
 */
void FRM_FeedLine(const uint8_t *line, uint16_t bytes, uint8_t field, uint16_t row_in_field)
{
    /* F=1 是 BT.656 第二场；PAL 常规对应偶场。 */
    if (field != CAP_SELECTED_F) return;

    /* 2) 纵向抽行：只在特定物理行写一行输出 */
    if ((row_in_field % (CAP_LINES_PER_FIELD / OUT_H)) != 0) return;
    if (out_row >= OUT_H) return;                 /* 一场够了，等收尾 */

    /* 3) 从 YUV422 里抠 Y：位置 1,3,5,... */
    /*    为省栈，就地用 block 尾部当临时也行；这里直接边扫边写 */
    uint8_t  yline[OUT_W];
    uint16_t ycnt = 0;
    for (uint16_t i = 1; i < bytes && ycnt < OUT_W * h_step; i += 2) {
        yline[ycnt++] = line[i];                 /* 取 Y */
    }

    /* 4) 横向抽成 OUT_W */
    uint8_t  out[OUT_W];
    uint16_t src = 0, dst = 0;
    uint16_t step = (ycnt > OUT_W) ? (ycnt / OUT_W) : 1;
    while (dst < OUT_W && src < ycnt) { out[dst++] = yline[src]; src += step; }
    while (dst < OUT_W) out[dst++] = yline[ycnt ? ycnt - 1 : 0];

    /* 5) 追进当前块 */
    memcpy(&block[block_rows * OUT_W], out, OUT_W);
    block_rows++;
    out_row++;

    /* 6) 攒够一块就发，不等整帧 */
    if (block_rows >= BLOCK_ROWS) {
        UTX_SendBlock(out_row - block_rows, block, block_rows * OUT_W);
        block_rows = 0;
    }
}

/* 一场收尾：把不满一块的尾巴发出去，并标 EOF */
void FRM_Finalize(void)
{
    if (block_rows > 0) {
        UTX_SendBlock(out_row - block_rows, block, block_rows * OUT_W);
        block_rows = 0;
    }
    UTX_SendEOF();
    out_row = 0;      /* 下一场从头来 */
}

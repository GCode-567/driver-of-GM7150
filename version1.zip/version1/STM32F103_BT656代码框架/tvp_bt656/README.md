# GM7150 + BT.656 capture draft

This directory is an unvalidated prototype, not a buildable or hardware-ready
firmware project. Do not copy its capture or transmission code into the main
project as-is.

## Confirmed requirements

- Decoder: GM7150. Its register setup and lock-status checks are intentionally
  not included; use the exact module documentation before implementing them.
- Input to the MCU: 8-bit BT.656 on PB8-PB15.
- Video standard: PAL.
- Capture goal: select one field, currently described as the even field. The
  prototype's `CAP_SELECTED_F` value is provisional and must be measured.
- UART: USART1 at 500000 baud, subject to confirming the PC-side configuration.

The BT.656 F bit identifies a field, but do not assume its value corresponds to
the desired even field until the GM7150 output is checked against a known
signal. Update `CAP_SELECTED_F` only after that check.

## Feasibility assessment

The current `EXTI0`-per-PCLK-byte approach is not a sound basis for reliable
full-rate capture on an STM32F103C8. The F103 has no DCMI, and software interrupt
handling for every byte of a BT.656 stream can exceed the CPU's available
processing budget. Its 20 KB SRAM also cannot hold a field of raw video.

At 500000 baud with 8N1 framing, UART carries at most about 50 KB/s before
protocol overhead. Sending a complete raw field is therefore not practical,
and UART flow control cannot pause a BT.656 source by itself.

Before developing the capture pipeline, measure the actual PCLK and confirm
whether the GM7150 module can reduce or gate its output. If it cannot, use a
capture-capable MCU or external capture hardware (for example, a FIFO/FPGA).
Do not treat GPIO EXTI sampling as a proven solution.

## Recommended implementation direction

1. Verify GM7150 power, reset, I2C address/register sequence, lock status, and
   BT.656 timing using the module documentation and measurement equipment.
2. Confirm SAV/EAV codes and the F-bit value for the field intended to be kept.
   Count active lines from BT.656 markers; do not use VSYNC as a substitute for
   embedded synchronization.
3. Prove byte capture at the measured PCLK before adding image processing.
4. If capture is reliable, extract active Y samples from the selected field,
   downsample to a size the UART can sustain, and transmit only that image data.
   Define an explicit overflow policy; do not silently drop arbitrary blocks.

## Prototype files

`capture.*`, `frame.*`, `uart_tx.*`, `main.c`, and
`stm32f1xx_it_hooks.c` preserve earlier experiments only. They are not yet a
consistent implementation: timing feasibility, field mapping, synchronization
handling, buffering, and DMA ownership still require redesign and validation.

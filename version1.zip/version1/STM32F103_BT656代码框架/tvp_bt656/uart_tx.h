#ifndef UART_TX_H
#define UART_TX_H

#include <stdint.h>

void UTX_Init(void);
void UTX_SendBlock(uint16_t row_off, const uint8_t *payload, uint16_t len);
void UTX_SendEOF(void);

#endif

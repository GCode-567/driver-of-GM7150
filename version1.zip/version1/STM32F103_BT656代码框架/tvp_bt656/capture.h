#ifndef CAPTURE_H
#define CAPTURE_H

#include <stdint.h>

/* ---- 调参区（根据实测 PAL 流修改） ---- */
#define CAP_LINES_PER_FIELD  288u   /* PAL 一场有效行数；NTSC 改 240 */
#define CAP_MIN_LINE_BYTES   1200u  /* 有效区字节下限，防误判（720*2=1440）*/
#define CAP_SELECTED_F       1u     /* 暂定值；须用实际 BT.656 流确认偶场对应的 F 位 */

void CAP_Init(void);

/* 以下两个在 stm32f1xx_it.c 的 EXTI0/EXTI1 里调用 */
void CAP_PCLK_IRQ(void);
void CAP_VSYNC_IRQ(void);

extern volatile uint8_t  cap_field_done;
extern volatile uint32_t cap_sync_lost;
extern volatile uint32_t cap_line_short;
extern volatile uint32_t cap_lines_ok;

#endif

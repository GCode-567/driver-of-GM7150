/**
 * stm32f1xx_it.c —— 只改这两个 EXTI 处理函数
 * （其余 NVIC、SysTick 保持 CubeMX 生成）
 */
#include "stm32f1xx_hal.h"
#include "capture.h"

/* EXTI0 = PCLK 上升沿 */
void EXTI0_IRQHandler(void)
{
    if (__HAL_GPIO_EXTI_GET_IT(GPIO_PIN_0)) {
        CAP_PCLK_IRQ();
        __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_0);
    }
}

/* EXTI1 = VSYNC 下降沿（兜底） */
void EXTI1_IRQHandler(void)
{
    if (__HAL_GPIO_EXTI_GET_IT(GPIO_PIN_1)) {
        CAP_VSYNC_IRQ();
        __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_1);
    }
}

/**
 * uart_tx.c —— DMA 乒乓发送：小图块 → PC
 *
 * 帧协议（PC 按此收齐再拼图）：
 *   AA 55 | fmt(1) | seq(1) | row_off_h row_off_l | bytes_h bytes_l | payload | chk(1)
 *   fmt: 0x01 = 灰度块   0x02 = EOF(无 payload)
 *   chk: 前面所有字节异或
 *
 * 规则：主循环只 UTX_SendBlock()，绝不等待；DMA 回调里只清 busy。
 */

#include "uart_tx.h"
#include "usart.h"     /* huart1 在这里 */
#include <string.h>

#define UART_TX_BUF_SIZE   (4 + 2 + 2 + 512)   /* 头(4)+row(2)+len(2)+payload，按需调 */
#define PAYLOAD_MAX         (320 * 16)          /* 必须 >= frame.c 的 BLOCK 大小 */

static uint8_t  buf[2][UART_TX_BUF_SIZE] __attribute__((aligned(4)));
static uint8_t  busy[2] = {0, 0};
static uint8_t  seq = 0;

/* 打包：返回整帧长度（含头尾） */
static uint16_t pack(uint8_t *p, uint8_t fmt, uint16_t row_off,
                     const uint8_t *payload, uint16_t len)
{
    uint8_t *h = p;
    p[0] = 0xAA; p[1] = 0x55; p[2] = fmt; p[3] = seq++;
    p[4] = (uint8_t)(row_off >> 8); p[5] = (uint8_t)row_off;
    p[6] = (uint8_t)(len >> 8);     p[7] = (uint8_t)len;
    uint8_t chk = 0;
    for (int i = 0; i < 8; i++) chk ^= h[i];
    memcpy(p + 8, payload, len);
    for (uint16_t i = 0; i < len; i++) chk ^= payload[i];
    p[8 + len] = chk;
    return 8 + len + 1;
}

/* DMA 发送完成回调（HAL 自动调用） */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance != USART1) return;
    /* 找到刚发完的那块，清 busy；这里用“非 busy 且上一次启动”的简单策略：
       因为只有两块，直接把“不在发”的那块判一下即可；更严谨可用 huart->pTxBuffPtr 比对 */
    for (int i = 0; i < 2; i++) {
        if (busy[i] && huart->pTxBuffPtr == buf[i]) {
            busy[i] = 0;
            break;
        }
    }
}

void UTX_Init(void)
{
    memset(buf, 0, sizeof buf);
    busy[0] = busy[1] = 0;
    seq = 0;
}

void UTX_SendBlock(uint16_t row_off, const uint8_t *payload, uint16_t len)
{
    if (len == 0 || len > PAYLOAD_MAX) return;

    int slot = -1;
    for (int i = 0; i < 2; i++) if (!busy[i]) { slot = i; break; }
    if (slot < 0) return;                     /* 两块都忙：本块丢弃，保实时性 */

    uint16_t n = pack(buf[slot], 0x01, row_off, payload, len);
    busy[slot] = 1;
    /* 若上一帧还没真正走 DMA，HAL 会返回 BUSY；这里直接忽略，避免卡死 */
    if (HAL_UART_Transmit_DMA(&huart1, buf[slot], n) != HAL_OK)
        busy[slot] = 0;
}

void UTX_SendEOF(void)
{
    uint8_t eof[9];
    eof[0] = 0xAA; eof[1] = 0x55; eof[2] = 0x02; eof[3] = seq++;
    eof[4] = eof[5] = eof[6] = eof[7] = 0;    /* row=0, len=0 */
    uint8_t chk = 0; for (int i = 0; i < 8; i++) chk ^= eof[i];
    eof[8] = chk;
    /* EOF 走阻塞发，确保最后一块先到；也可同样走 DMA，这里取简单稳妥 */
    HAL_UART_Transmit(&huart1, eof, 9, 100);
}

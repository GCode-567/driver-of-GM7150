#ifndef FRAME_H
#define FRAME_H

#include <stdint.h>

void FRM_Init(uint16_t h_decim);
void FRM_FeedLine(const uint8_t *line, uint16_t bytes, uint8_t field, uint16_t row_in_field);
void FRM_Finalize(void);

#endif

set(CMAKE_SYSTEM_NAME               Generic)
set(CMAKE_SYSTEM_PROCESSOR          arm)

set(CMAKE_C_COMPILER_FORCED TRUE)
set(CMAKE_CXX_COMPILER_FORCED TRUE)
set(CMAKE_C_COMPILER_ID GNU)
set(CMAKE_CXX_COMPILER_ID GNU)

# Some default GCC settings
set(TOOLCHAIN_PREFIX                arm-none-eabi-)

set(ARM_NONE_EABI_TOOLCHAIN_PATH "" CACHE PATH
    "Directory containing the arm-none-eabi toolchain binaries")

if(NOT ARM_NONE_EABI_TOOLCHAIN_PATH)
    find_program(ARM_NONE_EABI_GCC NAMES ${TOOLCHAIN_PREFIX}gcc)
    if(ARM_NONE_EABI_GCC)
        get_filename_component(ARM_NONE_EABI_TOOLCHAIN_PATH
            "${ARM_NONE_EABI_GCC}" DIRECTORY)
    elseif(WIN32)
        file(GLOB _arm_toolchain_bins
            "C:/ST/STM32CubeIDE*/STM32CubeIDE/plugins/com.st.stm32cube.ide.mcu.externaltools.gnu-tools-for-stm32.*/tools/bin")
        list(SORT _arm_toolchain_bins)
        list(REVERSE _arm_toolchain_bins)
        foreach(_arm_toolchain_bin IN LISTS _arm_toolchain_bins)
            if(EXISTS "${_arm_toolchain_bin}/${TOOLCHAIN_PREFIX}gcc.exe")
                set(ARM_NONE_EABI_TOOLCHAIN_PATH "${_arm_toolchain_bin}")
                break()
            endif()
        endforeach()
    endif()
endif()

if(ARM_NONE_EABI_TOOLCHAIN_PATH)
    if(WIN32)
        set(_arm_tool_suffix ".exe")
    else()
        set(_arm_tool_suffix "")
    endif()
    set(_arm_tool_prefix "${ARM_NONE_EABI_TOOLCHAIN_PATH}/${TOOLCHAIN_PREFIX}")
    set(CMAKE_C_COMPILER "${_arm_tool_prefix}gcc${_arm_tool_suffix}")
    set(CMAKE_CXX_COMPILER "${_arm_tool_prefix}g++${_arm_tool_suffix}")
    set(CMAKE_LINKER "${_arm_tool_prefix}g++${_arm_tool_suffix}")
    set(CMAKE_OBJCOPY "${_arm_tool_prefix}objcopy${_arm_tool_suffix}")
    set(CMAKE_SIZE "${_arm_tool_prefix}size${_arm_tool_suffix}")
else()
    set(CMAKE_C_COMPILER ${TOOLCHAIN_PREFIX}gcc)
    set(CMAKE_CXX_COMPILER ${TOOLCHAIN_PREFIX}g++)
    set(CMAKE_LINKER ${TOOLCHAIN_PREFIX}g++)
    set(CMAKE_OBJCOPY ${TOOLCHAIN_PREFIX}objcopy)
    set(CMAKE_SIZE ${TOOLCHAIN_PREFIX}size)
endif()

set(CMAKE_ASM_COMPILER "${CMAKE_C_COMPILER}")

set(CMAKE_EXECUTABLE_SUFFIX_ASM     ".elf")
set(CMAKE_EXECUTABLE_SUFFIX_C       ".elf")
set(CMAKE_EXECUTABLE_SUFFIX_CXX     ".elf")

set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)

# MCU specific flags
set(TARGET_FLAGS "-mcpu=cortex-m3 ")

set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} ${TARGET_FLAGS}")
set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -Wall -Wextra -Wpedantic -fdata-sections -ffunction-sections")
if(CMAKE_BUILD_TYPE MATCHES Debug)
    set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -O0 -g3")
endif()
if(CMAKE_BUILD_TYPE MATCHES Release)
    set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -Os -g0")
endif()

set(CMAKE_ASM_FLAGS "${CMAKE_C_FLAGS} -x assembler-with-cpp -MMD -MP")
set(CMAKE_CXX_FLAGS "${CMAKE_C_FLAGS} -fno-rtti -fno-exceptions -fno-threadsafe-statics")

set(CMAKE_C_LINK_FLAGS "${TARGET_FLAGS}")
set(CMAKE_C_LINK_FLAGS "${CMAKE_C_LINK_FLAGS} -T \"${CMAKE_SOURCE_DIR}/STM32F103C8Tx_FLASH.ld\"")
set(CMAKE_C_LINK_FLAGS "${CMAKE_C_LINK_FLAGS} --specs=nano.specs")
set(CMAKE_C_LINK_FLAGS "${CMAKE_C_LINK_FLAGS} -Wl,-Map=${CMAKE_PROJECT_NAME}.map -Wl,--gc-sections")
set(CMAKE_C_LINK_FLAGS "${CMAKE_C_LINK_FLAGS} -Wl,--start-group -lc -lm -Wl,--end-group")
set(CMAKE_C_LINK_FLAGS "${CMAKE_C_LINK_FLAGS} -Wl,--print-memory-usage")

set(CMAKE_CXX_LINK_FLAGS "${CMAKE_C_LINK_FLAGS} -Wl,--start-group -lstdc++ -lsupc++ -Wl,--end-group")